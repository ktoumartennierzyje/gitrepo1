/*
 * tab8.cpp
 * Copyright 2019  <>
 */


#include <iostream>
using namespace std;
int main(int argc, char **argv)
{
    int tab[5][7];
    srand(time(NULL));
    for (int i = 0; i<6; i++ ){
        for(int j = 0; j<8: j++){
        tab[i][j] = rand()%10;
        }
        }
    for (int j = 0; j<5; j++){
        for (j = 0; j<5; j++){
            tab[j][0]
            min1 = 0
        if (min>tab[i])
        {
            min = tab[j];
        }
            }
        }
    return 0;
}

